package model;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DTOCompany {

    private Long id;

    @NotNull
    private String name;
}
