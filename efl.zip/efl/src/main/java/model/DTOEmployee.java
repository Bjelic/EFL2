package model;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DTOEmployee {

    private Long id;
    @NotNull
    private String name;
    @NotNull
    private String surname;
    @NotNull
    private String email;
    @NotNull
    private String address;
    @NotNull
    private Long salary;
    @NotNull
    private EntityCompany company;
}
