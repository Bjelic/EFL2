package controller;

import lombok.extern.slf4j.Slf4j;
import model.DTOEmployee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import service.ServiceEmployee;

import javax.validation.Valid;
import java.util.List;


@Slf4j
@RestController
@RequestMapping("api/employee")
public class EntityController {

    @Autowired
    private ServiceEmployee serviceEmployee;

    @GetMapping
    public List<DTOEmployee> findAll() {
        log.info("Request: Find All Employees");
        return serviceEmployee.findAll();
    }

    @GetMapping("/{id}")
    public DTOEmployee findById(@PathVariable("id") Long id) {
        log.info(String.format("Request: Find Employee by id = %d", id));
        return serviceEmployee.findById(id);
    }

    @PostMapping
    public DTOEmployee create(@Valid @RequestBody DTOEmployee dto) {
        log.info(String.format("Request: Create Employee. Data = %s", dto));
        return serviceEmployee.create(dto);
    }

    @PutMapping
    public DTOEmployee update(@Valid @RequestBody DTOEmployee dto) {
        log.info(String.format("Request: Update Employee. Data = %s", dto));
        return serviceEmployee.update(dto);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable("id") long id) {
        log.info(String.format("Request: Employee with id, has been deleted", id));
        serviceEmployee.deleteById(id);
    }

    @GetMapping("/{salary}")
    public Long findByAvgSalary(@PathVariable("salary") long salary) {
        log.info(String.format("Request: Average Salary in the company"));
        return serviceEmployee.findByAvgSalary(salary);
    }
}
