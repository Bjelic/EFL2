package service;

import mapper.MapperEmployee;
import model.DTOEmployee;
import model.EntityEmployee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import repository.RepositoryEmployee;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ServiceEmployeeImpl implements ServiceEmployee {

    @Autowired
    private RepositoryEmployee repositoryEmployee;

    @Autowired
    private MapperEmployee mapperEmployee;


    @Override
    @Transactional(readOnly = true)
    public List<DTOEmployee> findAll() {
        List<EntityEmployee> employees = repositoryEmployee.findAll();
        return employees.stream()
                .map(item -> mapperEmployee.fromEntityToDto(item))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public DTOEmployee findById(long id) {
        Optional<EntityEmployee> entityEmployee = repositoryEmployee.findById(id);
        if (entityEmployee.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    String.format("Employee with id = %d does not exist", id));
        }

        return mapperEmployee.fromEntityToDto(entityEmployee.get());
    }

    @Override
    @Transactional
    public DTOEmployee create(DTOEmployee employee) {
        if (employee.getId() != null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    String.format("Employee can't be created with provided id = %d. Id must be null.", employee.getId()));
        }
        EntityEmployee entityEmployee = mapperEmployee.fromDtoToEntity(employee);
        EntityEmployee createdEmployee = repositoryEmployee.save(entityEmployee);

        return mapperEmployee.fromEntityToDto(createdEmployee);
    }

    @Override
    public DTOEmployee update(DTOEmployee employee) {
        if (employee.getId() != null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    String.format("Employee can't be created with provided id = %d. Id must be null.", employee.getId()));
        }
        Optional<EntityEmployee> entity = repositoryEmployee.findById(employee.getId());
        if (entity.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    String.format("Can't update Employee with id = %d because Employee doesn't exist", employee.getId()));
        }

        EntityEmployee entityEmployee = mapperEmployee.fromDtoToEntity(employee);
        EntityEmployee updatedEmployee = repositoryEmployee.save(entityEmployee);

        return mapperEmployee.fromEntityToDto(updatedEmployee);
    }

    @Override
    public void deleteById(long id) {
        Optional<EntityEmployee> entityEmployee = repositoryEmployee.findById(id);
        if (entityEmployee.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    String.format("Can't delete Employee with id = %d because Employee doesn't exist", id));
        }
        repositoryEmployee.deleteById(id);
    }

    @Override
    public Long findByAvgSalary(long salary) {
        Long entityEmployee = repositoryEmployee.findByAvgSalary(salary);

        return entityEmployee;
    }
}
