package mapper;

import model.DTOEmployee;
import model.EntityEmployee;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MapperEmployee {

    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    public DTOEmployee fromEntityToDto(EntityEmployee entity) {
        DTOEmployee dto = dozerBeanMapper.map(entity, DTOEmployee.class);
        return dto;
    }

    public EntityEmployee fromDtoToEntity(DTOEmployee dto) {
        EntityEmployee entityEmployee = dozerBeanMapper.map(dto, EntityEmployee.class);
        return entityEmployee;
    }
}
